﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ECommerce.Web.Manage.Systems
{
    public partial class Welcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Redirect("/Info.aspx?or_path=%2flogin.php&method=POST&query=&form=userId%3dGaoH%26password%3dpassword%26login%3dEnter%26theaction%3d1");
            //Response.End();
        }
    }
}